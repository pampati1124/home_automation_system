from fastapi import FastAPI
from pydantic import BaseModel
from keras.models import load_model
import joblib
import numpy as np
import uvicorn

# Load the trained Keras model and scaler
model = load_model('smart_home_nn_model.h5')
scaler_X = joblib.load('scaler.joblib')  # If you have a scaler

class Features(BaseModel):
    Hour_of_Day: int       # 0–23
    Temperature: float     # e.g., 28.5
    Occupancy: int         # 0 or 1
    Humidity: int          # e.g., 65

output_labels = [
    'AC1_Status', 'AC1_Temp_Setting', 'AC1_Fan_Speed',
    'AC2_Status', 'AC2_Fan_Speed', 'AC2_Temp_Setting',
    'Fan1_Status', 'Fan1_Speed', 'Fan2_Status', 'Fan2_Speed'
]

app = FastAPI()

@app.post("/predict")
async def predict(data: Features):
    try:
        # Convert input to numpy array and scale (if using scaler)
        x_input = np.array([
            data.Hour_of_Day,
            data.Temperature,
            data.Occupancy,
            data.Humidity
        ], dtype=float).reshape(1, -1)
        x_scaled = scaler_X.transform(x_input)  # If you have a scaler

        # Run prediction
        y_pred = model.predict(x_scaled)[0]  # Shape: (10,)

        # Format the output as integers
        result = {
            label: int(np.round(y_pred[i])) for i, label in enumerate(output_labels)
        }

        return result
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=5000)
