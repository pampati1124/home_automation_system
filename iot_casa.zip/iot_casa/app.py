from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
from datetime import datetime

app = Flask(__name__)

# Load the model and scaler
model = joblib.load('smart_home_model.joblib')
scaler = joblib.load('scaler.joblib')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get values from the form
        temperature = float(request.form['temperature'])
        humidity = float(request.form['humidity'])
        light = float(request.form['light'])
        co2 = float(request.form['co2'])
        humidity_ratio = float(request.form['humidity_ratio'])
        
        # Get current hour
        hour_of_day = datetime.now().hour
        
        # Create feature array
        features = np.array([[hour_of_day, temperature, humidity, light, co2, humidity_ratio]])
        
        # Scale the features
        scaled_features = scaler.transform(features)
        
        # Make prediction
        prediction = model.predict(scaled_features)
        
        # Format the prediction result
        result = {
            'temperature': f"{temperature:.1f}°C",
            'humidity': f"{humidity:.1f}%",
            'light': f"{light:.1f} lux",
            'co2': f"{co2:.1f} ppm",
            'humidity_ratio': f"{humidity_ratio:.3f}",
            'prediction': f"Analysis complete. Model prediction: {prediction[0]:.2f}"
        }
        
        return render_template('index.html', prediction=result)
        
    except Exception as e:
        return render_template('index.html', prediction=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True) 