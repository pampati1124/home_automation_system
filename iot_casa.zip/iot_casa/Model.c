#include <stdio.h>
#include <math.h>
#include <stdint.h>

// Function declarations
float predict(float* features);

// Helper functions
float sigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

float relu(float x) {
    return x > 0 ? x : 0;
}

// Model prediction function
float predict(float* features) {
    // Scale the input features
    float scaled_features[4];
    float mean[4] = {11.4569728, 24.1208195, 0.899894995, 39.1717171};  // Your exact means
    float scale[4] = {6.92469016, 4.66742376, 0.30013996, 7.92766198};   // Your exact scales
    
    for(int i = 0; i < 4; i++) {
        scaled_features[i] = (features[i] - mean[i]) / scale[i];
    }
    
    // Model prediction code
    float prediction = 0.0f;
    
    // Tree 0
    if (scaled_features[1] <= 0.5f) {
        if (scaled_features[0] <= -0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[2] <= 0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Tree 1
    if (scaled_features[3] <= 0.5f) {
        if (scaled_features[1] <= 0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[2] <= 0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Apply sigmoid for binary classification
    prediction = sigmoid(prediction);
    
    return prediction;
}

// Main function for testing
int main() {
    float features[4] = {14.0, 25.0, 1.0, 60.0};  // Example input
    float result = predict(features);
    printf("Prediction: %f\n", result);
    return 0;
} 