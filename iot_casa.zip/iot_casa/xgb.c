#include <Arduino.h>
#include <stdint.h>
#include "driver/ledc.h"

// Pin Definitions
#define AC1_PIN 12         // AC1 control pin
#define AC2_PIN 13         // AC2 control pin
#define FAN1_PIN 14        // Fan1 control pin
#define FAN2_PIN 15        // Fan2 control pin
#define AC1_TEMP_PIN 25    // AC1 temperature control (PWM)
#define AC2_TEMP_PIN 26    // AC2 temperature control (PWM)
#define FAN1_SPEED_PIN 27  // Fan1 speed control (PWM)
#define FAN2_SPEED_PIN 32  // Fan2 speed control (PWM)

// Control Parameters
#define PWM_FREQ 5000
#define PWM_RESOLUTION LEDC_TIMER_8_BIT
#define PWM_CHANNEL_AC1 LEDC_CHANNEL_0
#define PWM_CHANNEL_AC2 LEDC_CHANNEL_1
#define PWM_CHANNEL_FAN1 LEDC_CHANNEL_2
#define PWM_CHANNEL_FAN2 LEDC_CHANNEL_3

// Fixed-point arithmetic definitions
#define Q_FACTOR 8  // Reduced from 12 to 8 to prevent overflow
#define FLOAT_TO_FIXED(x) ((int16_t)((x) * (1 << Q_FACTOR)))
#define FIXED_TO_FLOAT(x) ((float)(x) / (1 << Q_FACTOR))

// Global variables
int16_t last_predictions[10] = {0};
unsigned long last_update = 0;
const unsigned long UPDATE_INTERVAL = 5000;  // Update every 5 seconds

// Example input scenarios
const float example_scenarios[][4] = {
    {14.0, 25.0, 1.0, 60.0},  // Normal day, occupied
    {14.0, 30.0, 1.0, 70.0},  // Hot day, occupied
    {14.0, 20.0, 1.0, 50.0},  // Cool day, occupied
    {14.0, 25.0, 0.0, 60.0},  // Normal day, unoccupied
    {2.0, 25.0, 0.0, 60.0},   // Night time, unoccupied
    {2.0, 28.0, 1.0, 65.0}    // Night time, occupied, warm
};
int current_scenario = 0;

// XGBoost model parameters
#define N_ESTIMATORS 200
#define MAX_DEPTH 6
#define LEARNING_RATE 0.1
#define SUBSAMPLE 0.8
#define COLSAMPLE_BYTREE 0.8
#define REG_ALPHA 0.1
#define REG_LAMBDA 1.0

// StandardScaler parameters (pre-computed from training data)
const float SCALER_MEAN[] = {11.4569728, 24.1208195, 0.899894995, 39.1717171};  // Means for hour, temp, occ, humidity
const float SCALER_SCALE[] = {6.92469016, 4.66742376, 0.30013996, 7.92766198};   // Scales for hour, temp, occ, humidity

// Function declarations
void predict(int16_t* features, int16_t* predictions);
void update_controls(int16_t* predictions);
void get_example_input(int16_t* features);
void scale_features(float* features, float* scaled_features);
void predict_xgboost(float* scaled_features, float* predictions);

// Helper functions for fixed-point arithmetic
int16_t fixed_multiply(int16_t a, int16_t b) {
    int32_t temp = (int32_t)a * b;
    return (int16_t)(temp >> Q_FACTOR);
}

int16_t fixed_sigmoid(int16_t x) {
    // Optimized sigmoid lookup table
    const int16_t sigmoid_table[] = {
        FLOAT_TO_FIXED(0.0003f),  // -8
        FLOAT_TO_FIXED(0.0025f),  // -6
        FLOAT_TO_FIXED(0.0179f),  // -4
        FLOAT_TO_FIXED(0.1192f),  // -2
        FLOAT_TO_FIXED(0.5f),     // 0
        FLOAT_TO_FIXED(0.8808f),  // 2
        FLOAT_TO_FIXED(0.9820f),  // 4
        FLOAT_TO_FIXED(0.9975f),  // 6
        FLOAT_TO_FIXED(0.9997f)   // 8
    };
    
    if (x < FLOAT_TO_FIXED(-8.0f)) return 0;
    if (x > FLOAT_TO_FIXED(8.0f)) return FLOAT_TO_FIXED(1.0f);
    
    int index = (x + FLOAT_TO_FIXED(8.0f)) >> (Q_FACTOR - 3);
    if (index < 0) index = 0;
    if (index > 8) index = 8;
    return sigmoid_table[index];
}

int16_t fixed_relu(int16_t x) {
    return (x > 0) ? x : 0;
}

// Function to get example input
void get_example_input(int16_t* features) {
    // Get the current scenario values
    float hour = example_scenarios[current_scenario][0];
    float temp = example_scenarios[current_scenario][1];
    float occ = example_scenarios[current_scenario][2];
    float humidity = example_scenarios[current_scenario][3];

    // Debug print scenario
    Serial.printf("\nUsing Scenario %d:\n", current_scenario);
    Serial.printf("Hour: %.2f\n", hour);
    Serial.printf("Temperature: %.2f\n", temp);
    Serial.printf("Occupancy: %.2f\n", occ);
    Serial.printf("Humidity: %.2f\n", humidity);

    // Convert to fixed-point with bounds checking
    features[0] = FLOAT_TO_FIXED(fmax(0.0f, fmin(24.0f, hour)));  // Hour: 0-24
    features[1] = FLOAT_TO_FIXED(fmax(0.0f, fmin(50.0f, temp)));  // Temp: 0-50°C
    features[2] = FLOAT_TO_FIXED(fmax(0.0f, fmin(1.0f, occ)));    // Occ: 0-1
    features[3] = FLOAT_TO_FIXED(fmax(0.0f, fmin(100.0f, humidity))); // Humidity: 0-100%

    // Debug print fixed-point values
    Serial.println("\nFixed-point values:");
    Serial.printf("Hour (fixed): %d\n", features[0]);
    Serial.printf("Temp (fixed): %d\n", features[1]);
    Serial.printf("Occ (fixed): %d\n", features[2]);
    Serial.printf("Humidity (fixed): %d\n", features[3]);

    // Move to next scenario
    current_scenario = (current_scenario + 1) % (sizeof(example_scenarios) / sizeof(example_scenarios[0]));
}

// Function to scale input features
void scale_features(float* features, float* scaled_features) {
    for (int i = 0; i < 4; i++) {
        scaled_features[i] = (features[i] - SCALER_MEAN[i]) / SCALER_SCALE[i];
    }
}

// Model prediction function
void predict(int16_t* features, int16_t* predictions) {
    // Convert fixed-point inputs to float
    float raw_features[4];
    float scaled_features[4];
    
    for (int i = 0; i < 4; i++) {
        raw_features[i] = FIXED_TO_FLOAT(features[i]);
    }

    // Debug print raw inputs
    Serial.println("\nInput Values:");
    Serial.printf("Hour: %.2f\n", raw_features[0]);
    Serial.printf("Temperature: %.2f\n", raw_features[1]);
    Serial.printf("Occupancy: %.2f\n", raw_features[2]);
    Serial.printf("Humidity: %.2f\n", raw_features[3]);

    // Validate and correct inputs
    if (raw_features[1] < 0.0f || raw_features[1] > 50.0f) {
        Serial.println("Warning: Invalid temperature, defaulting to 25°C");
        raw_features[1] = 25.0f;
    }
    if (raw_features[3] < 0.0f || raw_features[3] > 100.0f) {
        Serial.println("Warning: Invalid humidity, defaulting to 60%");
        raw_features[3] = 60.0f;
    }
    if (raw_features[2] < 0.0f) raw_features[2] = 0.0f;
    if (raw_features[2] > 1.0f) raw_features[2] = 1.0f;

    // Scale features
    scale_features(raw_features, scaled_features);

    // Debug print scaled features
    Serial.println("\nScaled Features:");
    Serial.printf("Hour (scaled): %.2f\n", scaled_features[0]);
    Serial.printf("Temperature (scaled): %.2f\n", scaled_features[1]);
    Serial.printf("Occupancy (scaled): %.2f\n", scaled_features[2]);
    Serial.printf("Humidity (scaled): %.2f\n", scaled_features[3]);

    // Make prediction using XGBoost model
    float float_predictions[10];
    predict_xgboost(scaled_features, float_predictions);

    // Convert predictions to fixed-point
    for (int i = 0; i < 10; i++) {
        predictions[i] = FLOAT_TO_FIXED(float_predictions[i]);
    }
}

// Function to update control outputs
void update_controls(int16_t* predictions) {
    // Convert predictions to float for PWM control
    float ac1_status = FIXED_TO_FLOAT(predictions[0]);
    float ac1_temp = FIXED_TO_FLOAT(predictions[1]);
    float ac1_fan = FIXED_TO_FLOAT(predictions[2]);
    float ac2_status = FIXED_TO_FLOAT(predictions[3]);
    float ac2_fan = FIXED_TO_FLOAT(predictions[4]);
    float ac2_temp = FIXED_TO_FLOAT(predictions[5]);
    float fan1_status = FIXED_TO_FLOAT(predictions[6]);
    float fan1_speed = FIXED_TO_FLOAT(predictions[7]);
    float fan2_status = FIXED_TO_FLOAT(predictions[8]);
    float fan2_speed = FIXED_TO_FLOAT(predictions[9]);

    // Update PWM outputs using ESP32 native functions
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC1, (uint32_t)(ac1_status * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC1);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC2, (uint32_t)(ac2_status * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC2);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN1, (uint32_t)(fan1_status * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN1);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN2, (uint32_t)(fan2_status * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN2);

    // Print control outputs in a single block
    Serial.println("\nControl Outputs:");
    Serial.printf("AC1 Status: %.2f\n", ac1_status);
    Serial.printf("AC1 Temp: %.2f\n", ac1_temp);
    Serial.printf("AC1 Fan: %.2f\n", ac1_fan);
    Serial.printf("AC2 Status: %.2f\n", ac2_status);
    Serial.printf("AC2 Fan: %.2f\n", ac2_fan);
    Serial.printf("AC2 Temp: %.2f\n", ac2_temp);
    Serial.printf("Fan1 Status: %.2f\n", fan1_status);
    Serial.printf("Fan1 Speed: %.2f\n", fan1_speed);
    Serial.printf("Fan2 Status: %.2f\n", fan2_status);
    Serial.printf("Fan2 Speed: %.2f\n", fan2_speed);
    Serial.println(); // Add a blank line for better readability
}

// Function to make XGBoost prediction
void predict_xgboost(float* scaled_features, float* predictions) {
    // This is a simplified version of XGBoost prediction
    // In a real implementation, you would need to include the actual tree structure
    
    // Example prediction logic based on scaled features
    float temp = scaled_features[1];  // Scaled temperature
    float occ = scaled_features[2];   // Scaled occupancy
    float hour = scaled_features[0];  // Scaled hour
    
    // AC1 Control
    predictions[0] = (temp > 0.2 && occ > 0) ? 1.0 : 0.0;  // AC1 Status
    predictions[1] = 24.0 + (temp * 2.0);                  // AC1 Temp Setting
    predictions[2] = fmax(0.0, fmin(5.0, temp * 2.5));     // AC1 Fan Speed
    
    // AC2 Control
    predictions[3] = (temp > 0.4 && occ > 0) ? 1.0 : 0.0;  // AC2 Status
    predictions[4] = fmax(0.0, fmin(5.0, temp * 2.0));     // AC2 Fan Speed
    predictions[5] = 23.0 + (temp * 2.5);                  // AC2 Temp Setting
    
    // Fan1 Control
    predictions[6] = (temp > 0.0 && occ > 0) ? 1.0 : 0.0;  // Fan1 Status
    predictions[7] = fmax(0.0, fmin(5.0, temp * 2.0));     // Fan1 Speed
    
    // Fan2 Control
    predictions[8] = (temp > 0.2 && occ > 0) ? 1.0 : 0.0;  // Fan2 Status
    predictions[9] = fmax(0.0, fmin(5.0, temp * 1.8));     // Fan2 Speed
}

void process_controls(int16_t* features) {
    // Convert fixed-point inputs to float
    float raw_features[4];
    float scaled_features[4];
    float predictions[10];
    
    for (int i = 0; i < 4; i++) {
        raw_features[i] = FIXED_TO_FLOAT(features[i]);
    }

    // Print input values
    Serial.println("\nInput Values:");
    Serial.printf("Hour: %.2f\n", raw_features[0]);
    Serial.printf("Temperature: %.2f\n", raw_features[1]);
    Serial.printf("Occupancy: %.2f\n", raw_features[2]);
    Serial.printf("Humidity: %.2f\n", raw_features[3]);

    // Validate inputs
    if (raw_features[1] < 0.0f || raw_features[1] > 50.0f) {
        Serial.println("Warning: Invalid temperature, defaulting to 25°C");
        raw_features[1] = 25.0f;
    }
    if (raw_features[3] < 0.0f || raw_features[3] > 100.0f) {
        Serial.println("Warning: Invalid humidity, defaulting to 60%");
        raw_features[3] = 60.0f;
    }
    if (raw_features[2] < 0.0f) raw_features[2] = 0.0f;
    if (raw_features[2] > 1.0f) raw_features[2] = 1.0f;

    // Scale features
    scale_features(raw_features, scaled_features);

    // Make prediction using XGBoost model
    predict_xgboost(scaled_features, predictions);

    // Update PWM outputs
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC1, (uint32_t)(predictions[0] * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC1);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC2, (uint32_t)(predictions[3] * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC2);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN1, (uint32_t)(predictions[6] * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN1);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN2, (uint32_t)(predictions[8] * 255));
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN2);

    // Print control outputs
    Serial.println("\nControl Outputs:");
    Serial.printf("AC1 Status: %d\n", (int)round(predictions[0]));
    Serial.printf("AC1 Temp: %d\n", (int)round(predictions[1]));
    Serial.printf("AC1 Fan: %d\n", (int)round(predictions[2]));
    Serial.printf("AC2 Status: %d\n", (int)round(predictions[3]));
    Serial.printf("AC2 Fan: %d\n", (int)round(predictions[4]));
    Serial.printf("AC2 Temp: %d\n", (int)round(predictions[5]));
    Serial.printf("Fan1 Status: %d\n", (int)round(predictions[6]));
    Serial.printf("Fan1 Speed: %d\n", (int)round(predictions[7]));
    Serial.printf("Fan2 Status: %d\n", (int)round(predictions[8]));
    Serial.printf("Fan2 Speed: %d\n", (int)round(predictions[9]));
    Serial.println();
}

void setup() {
    Serial.begin(115200);
    while (!Serial) {
        ; // Wait for serial port to connect
    }
    
    // Configure PWM timer
    ledc_timer_config_t ledc_timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .duty_resolution = PWM_RESOLUTION,
        .timer_num = LEDC_TIMER_0,
        .freq_hz = PWM_FREQ,
        .clk_cfg = LEDC_AUTO_CLK
    };
    ledc_timer_config(&ledc_timer);
    
    // Configure PWM channels
    ledc_channel_config_t ledc_channel = {
        .gpio_num = AC1_PIN,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = PWM_CHANNEL_AC1,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0
    };
    ledc_channel_config(&ledc_channel);
    
    ledc_channel.gpio_num = AC2_PIN;
    ledc_channel.channel = PWM_CHANNEL_AC2;
    ledc_channel_config(&ledc_channel);
    
    ledc_channel.gpio_num = FAN1_PIN;
    ledc_channel.channel = PWM_CHANNEL_FAN1;
    ledc_channel_config(&ledc_channel);
    
    ledc_channel.gpio_num = FAN2_PIN;
    ledc_channel.channel = PWM_CHANNEL_FAN2;
    ledc_channel_config(&ledc_channel);
    
    // Set initial state
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC1, 0);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC1);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC2, 0);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_AC2);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN1, 0);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN1);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN2, 0);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, PWM_CHANNEL_FAN2);
}

void loop() {
    if (millis() - last_update >= UPDATE_INTERVAL) {
        // Get example input
        int16_t features[4];
        get_example_input(features);
        
        // Process inputs and update controls
        process_controls(features);
        
        last_update = millis();
    }
}