#!/usr/bin/env python3
"""
Smart Home Control API
AI-powered smart home device control based on sensor data using XGBoost
"""

from fastapi import FastAPI, HTTPException, Depends, Security, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
import joblib
import numpy as np
import pandas as pd
import os
import logging
from datetime import datetime
import uvicorn
from sklearn.preprocessing import StandardScaler

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Smart Home Control API",
    description="AI-powered smart home device control based on sensor data using XGBoost",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Templates
templates = Jinja2Templates(directory="templates")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security (Optional - you can disable this for local testing)
security = HTTPBearer(auto_error=False)
API_KEY = os.getenv("API_KEY", "test-api-key")

def verify_api_key(credentials: Optional[HTTPAuthorizationCredentials] = Security(security)):
    """Verify API key from Authorization header (Optional for local testing)"""
    # Skip API key verification for local development
    if not credentials:
        return None
    if credentials.credentials != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return credentials.credentials

# Pydantic models
class SensorData(BaseModel):
    """Input sensor data model with only required fields"""
    hour_of_day: int = Field(..., ge=0, le=23, description="Hour of day (0-23)")
    temperature: float = Field(..., ge=-50, le=60, description="Indoor temperature in Celsius")
    occupancy: int = Field(..., ge=0, le=1, description="Occupancy (0=empty, 1=occupied)")
    humidity: float = Field(..., ge=0, le=100, description="Humidity percentage")
    
    class Config:
        schema_extra = {
            "example": {
                "hour_of_day": 14,
                "temperature": 27.5,
                "occupancy": 1,
                "humidity": 65.0
            }
        }

class DeviceControl(BaseModel):
    """Output device control model - Updated to match your XGBoost model outputs"""
    ac1_status: float = Field(..., description="AC1 Status")
    ac1_temp_setting: float = Field(..., description="AC1 Temperature Setting")
    ac1_fan_speed: float = Field(..., description="AC1 Fan Speed")
    ac2_status: float = Field(..., description="AC2 Status")
    ac2_fan_speed: float = Field(..., description="AC2 Fan Speed")
    ac2_temp_setting: float = Field(..., description="AC2 Temperature Setting")
    fan1_status: float = Field(..., description="Fan1 Status")
    fan1_speed: float = Field(..., description="Fan1 Speed")
    fan2_status: float = Field(..., description="Fan2 Status")
    fan2_speed: float = Field(..., description="Fan2 Speed")
    timestamp: str = Field(..., description="Prediction timestamp")

class PredictionResponse(BaseModel):
    """API response model"""
    status: str
    prediction: DeviceControl
    input_data: SensorData

# Global variables
model = None
scaler = None
MODEL_PATH = "smart_home_model.joblib"
SCALER_PATH = "scaler.joblib"

# Feature columns as defined in your training script
FEATURE_COLUMNS = [
    'Hour_of_Day', 'Temperature', 'Occupancy', 'Humidity'
]

# Room ID columns (one-hot encoded)
ROOM_COLUMNS = []  # Will be populated when model is loaded

# Output labels as defined in your training script
OUTPUT_LABELS = [
    'AC1_Status', 'AC1_Temp_Setting', 'AC1_Fan_Speed', 'AC2_Status', 
    'AC2_Fan_Speed', 'AC2_Temp_Setting', 'Fan1_Status', 'Fan1_Speed', 
    'Fan2_Status', 'Fan2_Speed'
]

def load_model():
    """Load the trained XGBoost model and scaler"""
    global model, scaler, ROOM_COLUMNS
    try:
        if os.path.exists(MODEL_PATH):
            model = joblib.load(MODEL_PATH)
            logger.info(f"XGBoost model loaded successfully from {MODEL_PATH}")
            
            # Try to load scaler if it exists
            if os.path.exists(SCALER_PATH):
                scaler = joblib.load(SCALER_PATH)
                logger.info(f"Scaler loaded successfully from {SCALER_PATH}")
            else:
                logger.warning(f"Scaler file not found: {SCALER_PATH}. Creating a new scaler.")
                scaler = StandardScaler()
            
            # Get feature names from model if available
            if hasattr(model, 'feature_names_in_'):
                feature_names = model.feature_names_in_
                # Extract room columns (one-hot encoded)
                ROOM_COLUMNS = [col for col in feature_names if col.startswith('Room_ID_')]
                logger.info(f"Detected room columns: {ROOM_COLUMNS}")
            
            return True
        else:
            logger.error(f"Model file not found: {MODEL_PATH}")
            return False
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        return False

def preprocess_input(sensor_data: SensorData) -> np.ndarray:
    """Preprocess input data for XGBoost model prediction"""
    try:
        # Create base features with only required fields
        features_dict = {
            'Hour_of_Day': sensor_data.hour_of_day,
            'Temperature': sensor_data.temperature,
            'Occupancy': sensor_data.occupancy,
            'Humidity': sensor_data.humidity
        }
        
        # Create DataFrame with features in correct order
        feature_values = [features_dict[col] for col in FEATURE_COLUMNS]
        
        # Convert to DataFrame for consistency
        df = pd.DataFrame([feature_values], columns=FEATURE_COLUMNS)
        
        # Scale the features if scaler is available
        if scaler is not None:
            try:
                scaled_features = scaler.transform(df)
                return scaled_features
            except Exception as e:
                logger.warning(f"Error scaling features: {e}. Using unscaled features.")
                return df.values
        else:
            return df.values
            
    except Exception as e:
        logger.error(f"Error preprocessing input: {e}")
        raise

def format_prediction(prediction) -> DeviceControl:
    """Format XGBoost model prediction into DeviceControl object with processed values"""
    try:
        pred = prediction[0] if len(prediction.shape) > 1 else prediction
        
        # Process status outputs to be binary (0 or 1)
        ac1_status = 1 if float(pred[0]) > 0.5 else 0
        ac2_status = 1 if float(pred[3]) > 0.5 else 0
        fan1_status = 1 if float(pred[6]) > 0.5 else 0
        fan2_status = 1 if float(pred[8]) > 0.5 else 0
        
        # Process temperature settings to be rounded integers
        ac1_temp = max(16, min(30, round(float(pred[1]))))  # Limit between 16-30°C
        ac2_temp = max(16, min(30, round(float(pred[5]))))  # Limit between 16-30°C
        
        # Process fan speeds to be integers between 0-5
        ac1_fan = max(0, min(5, round(float(pred[2]))))
        ac2_fan = max(0, min(5, round(float(pred[4]))))
        fan1_speed = max(0, min(5, round(float(pred[7]))))
        fan2_speed = max(0, min(5, round(float(pred[9]))))
        
        # Create device control object with processed values
        device_control = DeviceControl(
            ac1_status=ac1_status,
            ac1_temp_setting=ac1_temp,
            ac1_fan_speed=ac1_fan,
            ac2_status=ac2_status,
            ac2_fan_speed=ac2_fan,
            ac2_temp_setting=ac2_temp,
            fan1_status=fan1_status,
            fan1_speed=fan1_speed,
            fan2_status=fan2_status,
            fan2_speed=fan2_speed,
            timestamp=datetime.now().isoformat()
        )
        
        return device_control
        
    except Exception as e:
        logger.error(f"Error formatting prediction: {e}")
        raise

# API Endpoints
@app.on_event("startup")
async def startup_event():
    """Load model on startup"""
    success = load_model()
    if not success:
        logger.warning("Failed to load model. API will not work properly.")

@app.get("/")
async def home(request: Request):
    """Serve the main page"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/predict")
async def predict(request: Request):
    """Handle form submission and return prediction"""
    try:
        form_data = await request.form()
        
        # Get values from the form
        hour_of_day = int(form_data['hour_of_day'])
        temperature = float(form_data['temperature'])
        occupancy = int(form_data['occupancy'])
        humidity = float(form_data['humidity'])
        
        # Create feature array in the correct order as expected by the model
        features = np.array([[hour_of_day, temperature, occupancy, humidity]])
        
        # Scale the features
        scaled_features = scaler.transform(features)
        
        # Make prediction
        prediction = model.predict(scaled_features)
        
        # Format the prediction result
        result = {
            'ac1_status': float(prediction[0][0]),
            'ac1_temp_setting': float(prediction[0][1]),
            'ac1_fan_speed': float(prediction[0][2]),
            'ac2_status': float(prediction[0][3]),
            'ac2_fan_speed': float(prediction[0][4]),
            'ac2_temp_setting': float(prediction[0][5]),
            'fan1_status': float(prediction[0][6]),
            'fan1_speed': float(prediction[0][7]),
            'fan2_status': float(prediction[0][8]),
            'fan2_speed': float(prediction[0][9])
        }
        
        # Convert form data to dict for template
        form_dict = {
            'hour_of_day': form_data['hour_of_day'],
            'temperature': form_data['temperature'],
            'occupancy': form_data['occupancy'],
            'humidity': form_data['humidity']
        }
        
        return templates.TemplateResponse("index.html", {
            "request": request,
            "prediction": result,
            "form_data": form_dict
        })
        
    except Exception as e:
        logger.error(f"Prediction error: {str(e)}")
        return templates.TemplateResponse("index.html", {
            "request": request,
            "prediction": f"Error: {str(e)}",
            "form_data": None
        })

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy" if model is not None else "unhealthy",
        "timestamp": datetime.utcnow().isoformat(),
        "model_loaded": model is not None,
        "scaler_loaded": scaler is not None,
        "version": "2.0.0"
    }

@app.post("/predict", response_model=PredictionResponse)
async def predict_device_control(sensor_data: SensorData):
    """
    Predict device control settings based on sensor data using XGBoost
    """
    try:
        if model is None:
            raise HTTPException(
                status_code=503,
                detail="XGBoost model not loaded. Please ensure the model file exists."
            )
        
        # Preprocess input
        X = preprocess_input(sensor_data)
        
        # Make prediction using XGBoost
        prediction = model.predict(X)
        
        # Format response
        device_control = format_prediction(prediction)
        
        logger.info(f"XGBoost prediction made for input: {sensor_data.dict()}")
        
        return PredictionResponse(
            status="success",
            prediction=device_control,
            input_data=sensor_data
        )
        
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

@app.post("/batch-predict")
async def batch_predict(sensor_data_list: List[SensorData]):
    """Batch prediction for multiple sensor readings"""
    try:
        if model is None:
            raise HTTPException(
                status_code=503,
                detail="XGBoost model not loaded. Please ensure the model file exists."
            )
        
        if len(sensor_data_list) > 100:
            raise HTTPException(
                status_code=400,
                detail="Batch size too large. Maximum 100 predictions at once."
            )
        
        results = []
        for sensor_data in sensor_data_list:
            X = preprocess_input(sensor_data)
            prediction = model.predict(X)
            device_control = format_prediction(prediction)
            
            results.append(PredictionResponse(
                status="success",
                prediction=device_control,
                input_data=sensor_data
            ))
        
        logger.info(f"Batch prediction completed for {len(results)} samples")
        return results
        
    except Exception as e:
        logger.error(f"Batch prediction error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Batch prediction failed: {str(e)}"
        )

@app.get("/model-info")
async def get_model_info():
    """Get information about the loaded XGBoost model"""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    model_info = {
        "model_type": "XGBoost Regressor",
        "model_class": type(model).__name__,
        "model_loaded": True,
        "scaler_loaded": scaler is not None,
        "supported_devices": ["AC1", "AC2", "Fan1", "Fan2"],
        "input_features": FEATURE_COLUMNS + ROOM_COLUMNS,
        "output_labels": OUTPUT_LABELS,
        "model_file": MODEL_PATH,
        "scaler_file": SCALER_PATH,
        "loaded_at": datetime.utcnow().isoformat()
    }
    
    # Add XGBoost specific info if available
    if hasattr(model, 'n_estimators'):
        model_info["n_estimators"] = model.n_estimators
    if hasattr(model, 'max_depth'):
        model_info["max_depth"] = model.max_depth
    if hasattr(model, 'learning_rate'):
        model_info["learning_rate"] = model.learning_rate
    
    return model_info

@app.get("/feature-importance")
async def get_feature_importance():
    """Get feature importance from the XGBoost model"""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
            feature_names = FEATURE_COLUMNS + ROOM_COLUMNS
            
            # Create feature importance dictionary
            importance_dict = {
                feature: float(importance) 
                for feature, importance in zip(feature_names, importances)
            }
            
            # Sort by importance
            sorted_importance = dict(sorted(importance_dict.items(), 
                                         key=lambda x: x[1], reverse=True))
            
            return {
                "feature_importance": sorted_importance,
                "top_5_features": list(sorted_importance.keys())[:5]
            }
        else:
            raise HTTPException(
                status_code=400, 
                detail="Model does not support feature importance"
            )
    except Exception as e:
        logger.error(f"Error getting feature importance: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get feature importance: {str(e)}"
        )

if __name__ == "__main__":
    # Run the server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
