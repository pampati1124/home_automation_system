#xgboost with ac fan 
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Load data
file_path = '/Users/sirivalli/Desktop/iot_casa/curtain and accent light edited.csv'

try:
    data = pd.read_csv(file_path)
    print(f"Dataset from '{file_path}' loaded successfully!")
    print(f"Original Dataset shape: {data.shape}")
    print("\nOriginal Dataset Head:")
    print(data.head())
except FileNotFoundError:
    print(f"Error: The file '{file_path}' was not found. Please ensure it's available in the execution environment (e.g., uploaded to Colab).")
    exit()
except Exception as e:
    print(f"Error loading dataset: {e}")
    exit()

# Define input features (X) and output labels (Y)
input_features_numerical = [
    'Hour_of_Day', 'Temperature', 'Occupancy', 'Humidity'
]

output_labels_new = [
    'AC1_Status','AC1_Temp_Setting','AC1_Fan_Speed', 'AC2_Status', 'AC2_Fan_Speed','AC2_Temp_Setting','Fan1_Status','Fan1_Speed', 'Fan2_Status', 'Fan2_Speed'
]

# Check if all specified input features are in the dataframe
missing_input_features = [f for f in input_features_numerical if f not in data.columns]
if missing_input_features:
    print(f"\nWarning: The following numerical input features were not found in the dataset: {missing_input_features}")
    input_features_numerical = [f for f in input_features_numerical if f in data.columns]
    print(f"Using available numerical input features: {input_features_numerical}")

# Check if all specified output labels are in the dataframe
missing_output_labels = [label for label in output_labels_new if label not in data.columns]
if missing_output_labels:
    print(f"\nWarning: The following output labels were not found in the dataset and will be excluded: {missing_output_labels}")
    output_labels_new = [label for label in output_labels_new if label in data.columns]
    print(f"Using available output labels: {output_labels_new}")

# Preprocess data: Only use the 4 required features, no categorical encoding
final_input_features = input_features_numerical.copy()

# Filter to ensure all final input features exist in the processed dataframe
data_processed = data.copy()
final_input_features = [f for f in final_input_features if f in data_processed.columns]

# Ensure no selected feature is missing before proceeding
missing_final_inputs = [f for f in final_input_features if f not in data_processed.columns]
if missing_final_inputs:
    print(f"Error: The following final input features are missing: {missing_final_inputs}")
    exit()
if not output_labels_new:
    print("Error: No valid output labels found in the dataset. Exiting.")
    exit()

X = data_processed[final_input_features]
Y = data_processed[output_labels_new]

# Data Type Validation
print("\nPerforming data type validation for features and labels before scaling...")
for col in X.columns:
    if not pd.api.types.is_numeric_dtype(X[col]):
        print(f"Error: Feature column '{col}' is not numeric ({X[col].dtype}). Please check preprocessing logic.")
        exit()
for col in Y.columns:
    if not pd.api.types.is_numeric_dtype(Y[col]):
        print(f"Error: Label column '{col}' is not numeric ({Y[col].dtype}). Please check preprocessing logic.")
        exit()
print("All feature and label columns are numeric. Data is ready for model training.")


# Split data into training, validation, and test sets
X_train, X_val_test, Y_train, Y_val_test = train_test_split(X, Y, test_size=0.2, random_state=42)
X_val, X_test, Y_val, Y_test = train_test_split(X_val_test, Y_val_test, test_size=0.5, random_state=42)

print(f"\nTraining set shape (X_train): {X_train.shape}")
print(f"Validation set shape (X_val): {X_val.shape}")
print(f"Testing set shape (X_test): {X_test.shape}")
print(f"Training labels shape (Y_train): {Y_train.shape}")
print(f"Validation labels shape (Y_val): {Y_val.shape}")
print(f"Testing labels shape (Y_test): {Y_test.shape}")

# Scale data
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_val_scaled = scaler_X.transform(X_val)
X_test_scaled = scaler_X.transform(X_test)

X_train_scaled_df = pd.DataFrame(X_train_scaled, columns=X_train.columns)
X_val_scaled_df = pd.DataFrame(X_val_scaled, columns=X_val.columns)
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X_test.columns)

# Train XGBoost model
print("\n--- Training XGBoost Model ---")
xgb_model = XGBRegressor(
 n_estimators=200,
 max_depth=6,
 learning_rate=0.1,
 subsample=0.8,
 colsample_bytree=0.8,
 reg_alpha=0.1,
 reg_lambda=1.0,
 eval_metric='rmse',
 random_state=42,
 n_jobs=-1,
 verbosity=0
)

print("XGBoost model initialized. Training...")
xgb_model.fit(X_train_scaled_df, Y_train)
print("XGBoost model training complete!")

# Make predictions
print("\n--- Making Predictions ---")
Y_pred_xgb_val = xgb_model.predict(X_val_scaled_df)
Y_pred_xgb_test = xgb_model.predict(X_test_scaled_df)
print("Predictions made on validation and test sets.")

# Evaluate model
print("\n--- Evaluating XGBoost Model ---")
mse_per_output_xgb_val = mean_squared_error(Y_val, Y_pred_xgb_val, multioutput='raw_values')
r2_per_output_xgb_val = r2_score(Y_val, Y_pred_xgb_val, multioutput='raw_values')

mse_per_output_xgb_test = mean_squared_error(Y_test, Y_pred_xgb_test, multioutput='raw_values')
r2_per_output_xgb_test = r2_score(Y_test, Y_pred_xgb_test, multioutput='raw_values')

# Define status labels for accuracy calculation (from previous context, assume these are binary)
status_labels = [
    'AC1_Status', 'AC2_Status', 'Fan1_Status', 'Fan2_Status',
    'MainLight_Status', 'BedLamp_Status', 'AccentLight_Status'
]
# Filter to only include status labels that are actually in the output_labels_new for this run
status_labels_in_outputs = [label for label in status_labels if label in output_labels_new]


print("\n--- Evaluation Metrics Per Output (XGBoost) ---")
for i, label in enumerate(output_labels_new):
    print(f"  {label}:")
    print(f"    Val MSE: {mse_per_output_xgb_val[i]:.4f}, Val R²: {r2_per_output_xgb_val[i]:.4f}")
    print(f"    Test MSE: {mse_per_output_xgb_test[i]:.4f}, Test R²: {r2_per_output_xgb_test[i]:.4f}")

    if label in status_labels_in_outputs: # Only calculate accuracy for binary status labels
        y_true_status_val = Y_val[label].values
        y_pred_status_val = np.round(Y_pred_xgb_val[:, i])
        y_true_status_test = Y_test[label].values
        y_pred_status_test = np.round(Y_pred_xgb_test[:, i])

        try:
            accuracy_val = accuracy_score(y_true_status_val.astype(int), y_pred_status_val.astype(int))
            accuracy_test = accuracy_score(y_true_status_test.astype(int), y_pred_status_test.astype(int))
            print(f"    Val Accuracy: {accuracy_val:.4f}, Test Accuracy: {accuracy_test:.4f}")
        except Exception as e:
            print(f"    Could not calculate accuracy for {label}: {e}")

# --- Add Overall Evaluation Metrics ---
overall_mse_xgb_val = mean_squared_error(Y_val, Y_pred_xgb_val)
overall_r2_xgb_val = r2_score(Y_val, Y_pred_xgb_val)

overall_mse_xgb_test = mean_squared_error(Y_test, Y_pred_xgb_test)
overall_r2_xgb_test = r2_score(Y_test, Y_pred_xgb_test)

print("\n--- Overall Evaluation Metrics (XGBoost) ---")
print(f"  Overall Validation MSE: {overall_mse_xgb_val:.4f}")
print(f"  Overall Validation R-squared: {overall_r2_xgb_val:.4f}")
print(f"  Overall Test MSE: {overall_mse_xgb_test:.4f}")
print(f"  Overall Test R-squared: {overall_r2_xgb_test:.4f}")

# Feature importance
print("\n--- Feature Importance from XGBoost ---")
importances_xgb = xgb_model.feature_importances_
feature_importance_df_xgb = pd.DataFrame({
 'Feature': final_input_features,
 'Importance': importances_xgb
})
feature_importance_df_xgb = feature_importance_df_xgb.sort_values(by='Importance', ascending=False)
print(feature_importance_df_xgb.head(15)) # Show top 15 features

# Plot feature importance
#plt.figure(figsize=(10,6))
#sns.barplot(x='Importance', y='Feature', data=feature_importance_df_xgb.head(15)) # Plot top 15
#plt.xlabel('Importance Score')
#plt.title('Top 15 Feature Importance (XGBoost)')
#plt.tight_layout()
#plt.show()
#joblib saving .
# saving the trained model using joblib 
import joblib
joblib.dump(xgb_model, 'smart_home_model.joblib')
# Add this line after training your model
joblib.dump(scaler_X, 'scaler.joblib')
