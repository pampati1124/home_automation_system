// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get all input fields
    const inputs = document.querySelectorAll('input[type="number"]');
    const select = document.querySelector('select');
    const form = document.querySelector('form');
    
    // Add input validation and real-time feedback
    inputs.forEach(input => {
        // Add input event listener for real-time validation
        input.addEventListener('input', function() {
            validateInput(this);
        });
        
        // Add focus event for better UX
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
            validateInput(this);
        });
    });
    
    // Add validation for select element
    select.addEventListener('change', function() {
        validateSelect(this);
    });
    
    // Form submission handling
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate all inputs before submission
        let isValid = true;
        inputs.forEach(input => {
            if (!validateInput(input)) {
                isValid = false;
            }
        });
        
        if (!validateSelect(select)) {
            isValid = false;
        }
        
        if (isValid) {
            // Show loading state
            const submitButton = document.querySelector('.predict-button');
            const originalText = submitButton.textContent;
            submitButton.textContent = 'Analyzing...';
            submitButton.disabled = true;
            
            // Submit the form
            this.submit();
        }
    });
    
    // Input validation function
    function validateInput(input) {
        const value = parseFloat(input.value);
        let isValid = true;
        let errorMessage = '';
        
        // Set reasonable ranges for each sensor type
        switch(input.id) {
            case 'hour_of_day':
                if (value < 0 || value > 23) {
                    isValid = false;
                    errorMessage = 'Hour must be between 0 and 23';
                }
                break;
            case 'temperature':
                if (value < -50 || value > 60) {
                    isValid = false;
                    errorMessage = 'Temperature should be between -50°C and 60°C';
                }
                break;
            case 'humidity':
                if (value < 0 || value > 100) {
                    isValid = false;
                    errorMessage = 'Humidity should be between 0% and 100%';
                }
                break;
        }
        
        // Update input styling based on validation
        if (!isValid) {
            input.classList.add('invalid');
            // Show error message
            let errorDiv = input.parentElement.querySelector('.error-message');
            if (!errorDiv) {
                errorDiv = document.createElement('div');
                errorDiv.className = 'error-message';
                input.parentElement.appendChild(errorDiv);
            }
            errorDiv.textContent = errorMessage;
        } else {
            input.classList.remove('invalid');
            // Remove error message if it exists
            const errorDiv = input.parentElement.querySelector('.error-message');
            if (errorDiv) {
                errorDiv.remove();
            }
        }
        
        return isValid;
    }
    
    // Select validation function
    function validateSelect(select) {
        const value = select.value;
        let isValid = true;
        
        if (value === '') {
            isValid = false;
            select.classList.add('invalid');
            let errorDiv = select.parentElement.querySelector('.error-message');
            if (!errorDiv) {
                errorDiv = document.createElement('div');
                errorDiv.className = 'error-message';
                select.parentElement.appendChild(errorDiv);
            }
            errorDiv.textContent = 'Please select an occupancy status';
        } else {
            select.classList.remove('invalid');
            const errorDiv = select.parentElement.querySelector('.error-message');
            if (errorDiv) {
                errorDiv.remove();
            }
        }
        
        return isValid;
    }
}); 