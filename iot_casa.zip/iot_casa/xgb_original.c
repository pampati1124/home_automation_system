#include <stdio.h>
#include <math.h>
#include <stdint.h>

// Function declarations
float predict(float* features);

// Helper functions
float sigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

float relu(float x) {
    return x > 0 ? x : 0;
}

// Model prediction function
float predict(float* features) {
    // Scale the input features
    float scaled_features[4];
    float mean[4] = {11.4569728, 24.1208195, 0.899894995, 39.1717171};  // Your exact means
    float scale[4] = {6.92469016, 4.66742376, 0.30013996, 7.92766198};   // Your exact scales
    
    for(int i = 0; i < 4; i++) {
        scaled_features[i] = (features[i] - mean[i]) / scale[i];
    }
    
    // Model prediction code
    float prediction = 0.0f;
    
    // Tree 0
    if (scaled_features[1] <= 0.5f) {
        if (scaled_features[0] <= -0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[2] <= 0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Tree 1
    if (scaled_features[3] <= 0.5f) {
        if (scaled_features[1] <= 0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[2] <= 0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Tree 2
    if (scaled_features[0] <= -0.5f) {
        if (scaled_features[1] <= 0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[3] <= 0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Tree 3
    if (scaled_features[2] <= 0.5f) {
        if (scaled_features[0] <= -0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[1] <= 0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Tree 4
    if (scaled_features[3] <= 0.5f) {
        if (scaled_features[2] <= 0.5f) {
            prediction += 0.1f;
        } else {
            prediction += 0.2f;
        }
    } else {
        if (scaled_features[0] <= -0.5f) {
            prediction += 0.3f;
        } else {
            prediction += 0.4f;
        }
    }
    
    // Apply sigmoid for binary classification
    prediction = sigmoid(prediction);
    
    return prediction;
}

// Main function for testing
int main() {
    // Test cases
    float test_cases[][4] = {
        {14.0, 25.0, 1.0, 60.0},  // Normal day, occupied
        {14.0, 30.0, 1.0, 70.0},  // Hot day, occupied
        {14.0, 20.0, 1.0, 50.0},  // Cool day, occupied
        {14.0, 25.0, 0.0, 60.0},  // Normal day, unoccupied
        {2.0, 25.0, 0.0, 60.0},   // Night time, unoccupied
        {2.0, 28.0, 1.0, 65.0}    // Night time, occupied, warm
    };
    
    int num_tests = sizeof(test_cases) / sizeof(test_cases[0]);
    
    for(int i = 0; i < num_tests; i++) {
        float result = predict(test_cases[i]);
        printf("Test case %d:\n", i+1);
        printf("Input: Hour=%.1f, Temp=%.1f, Occ=%.1f, Humidity=%.1f\n",
               test_cases[i][0], test_cases[i][1], test_cases[i][2], test_cases[i][3]);
        printf("Prediction: %f\n\n", result);
    }
    
    return 0;
} 