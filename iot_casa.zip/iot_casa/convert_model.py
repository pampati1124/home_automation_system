import xgboost as xgb
import m2cgen as m2c
import numpy as np

# Load your trained model
model = xgb.Booster()
model.load_model('your_model.json')  # or .model file

# Convert to C code
code = m2c.export_to_c(model)

# Create the C file with necessary includes and structure
c_code = """#include <stdio.h>
#include <math.h>
#include <stdint.h>

// Function declarations
float predict(float* features);

// Helper functions
float sigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

float relu(float x) {
    return x > 0 ? x : 0;
}

// Model prediction function
float predict(float* features) {
    // Scale the input features
    float scaled_features[4];
    float mean[4] = {11.4569728, 24.1208195, 0.899894995, 39.1717171};  // Your exact means
    float scale[4] = {6.92469016, 4.66742376, 0.30013996, 7.92766198};   // Your exact scales
    
    for(int i = 0; i < 4; i++) {
        scaled_features[i] = (features[i] - mean[i]) / scale[i];
    }
    
    // Model prediction code
    %s
    
    return prediction;
}

// Main function for testing
int main() {
    float features[4] = {14.0, 25.0, 1.0, 60.0};  // Example input
    float result = predict(features);
    printf("Prediction: %%f\\n", result);
    return 0;
}
""" % code

# Write the C code to a file
with open('xgb_converted.c', 'w') as f:
    f.write(c_code)

print("C code has been generated and saved to xgb_converted.c") 