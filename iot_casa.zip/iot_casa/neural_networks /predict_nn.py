from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
from tflite_runtime.interpreter import Interpreter
import uvicorn

# Load the scaler (if you want to keep preprocessing in the API)
scaler_X = joblib.load('scaler.joblib')

# Load the TFLite model and prepare the interpreter
interpreter = Interpreter(model_path="smart_home_nn_model.tflite")
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

class Features(BaseModel):
    Hour_of_Day: int       # 0–23
    Temperature: float     # e.g., 28.5
    Occupancy: int         # 0 or 1
    Humidity: int          # e.g., 65

output_labels = [
    'AC1_Status', 'AC1_Temp_Setting', 'AC1_Fan_Speed',
    'AC2_Status', 'AC2_Fan_Speed', 'AC2_Temp_Setting',
    'Fan1_Status', 'Fan1_Speed', 'Fan2_Status', 'Fan2_Speed'
]

app = FastAPI()

@app.post("/predict")
async def predict(data: Features):
    try:
        # Convert input to numpy array and scale
        x_input = np.array([
            data.Hour_of_Day,
            data.Temperature,
            data.Occupancy,
            data.Humidity
        ], dtype=np.float32).reshape(1, -1)
        x_scaled = scaler_X.transform(x_input)  # Scale if you have a scaler

        # Set input tensor
        interpreter.set_tensor(input_details[0]['index'], x_scaled)
        # Run inference
        interpreter.invoke()
        # Get output
        y_pred = interpreter.get_tensor(output_details[0]['index'])[0]

        # Format the output as integers
        result = {
            label: int(np.round(y_pred[i])) for i, label in enumerate(output_labels)
        }
        return result
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    uvicorn.run("predict_nn:app", host="0.0.0.0", port=5000)
